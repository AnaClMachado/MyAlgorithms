package projeto_parte2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Usuario extends Thread{
    
    private String nome;
    private int prioridade;
    private int num_documentos=5;
    public static Impressora impre = new Impressora();
    
    public Usuario(String nome, int prioridade) {
        this.nome = nome;
        this.prioridade = prioridade;
        start();
    }
    public void setNum_documentos(int num_documentos) {
        this.num_documentos = num_documentos;
    }

    public int getNum_documentos() {
        return num_documentos;
    }
  

    public int getPrioridade(){
        return prioridade;
    }

    public String getNome(){
        return nome;
    }
    
    @Override
    public void run(){
        int i=0;
        do{
            if(impre.adcFila(this)==1){
                num_documentos--;
            }else{
                
            }
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
            }
            i++;
        }while(num_documentos>=0);
        
    }
    
}
