package projeto_parte2;

import java.util.Random;

public class Projeto_parte2 {
    public static void main(String[] args) {        
    
        Usuario um = new Usuario("Usuario 1",1);
        Usuario dois = new Usuario("Usuario 2",2);
        Usuario tres = new Usuario("Usuario 3",3);
        Usuario quatro = new Usuario("Usuario 4",4);
        Usuario cinco = new Usuario("Usuario 5",5);
        Usuario seis = new Usuario("Usuario 6",6);     
        
        
    }
        
        
}
