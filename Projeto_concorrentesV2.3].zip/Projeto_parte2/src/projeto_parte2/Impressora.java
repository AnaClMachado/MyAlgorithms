package projeto_parte2;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Impressora{
    
    public Queue<Usuario>fila=new LinkedList<>();
   // int fila[] = new int[3];
    public int n=0;
    Lock chave = new ReentrantLock();

    
    public synchronized void imprime(){
        try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {
            Logger.getLogger(Impressora.class.getName()).log(Level.SEVERE, null, ex);
        }
        String nome;
        int documento;
        //System.out.println("IMPRIMINDO \n"+nome+" DOCUMENTO "+documento);
        fila.remove();
        n--;
        
    }
    public int adcFila(Usuario e){     
        chave.lock();
        try{
            if(n<3){                
                fila.add(e);
                n++;
                System.out.println(fila.element().getNome()+" DOCUMENTO-"+fila.element().getNum_documentos());
                return 1;
            }else{            
                System.out.println("*FILA CHEIA*\n"+Thread.currentThread().getName());
                return 1;
            }
        } finally{
            chave.unlock();
        }
    }
}
