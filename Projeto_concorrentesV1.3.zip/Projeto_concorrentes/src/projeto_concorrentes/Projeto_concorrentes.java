package projeto_concorrentes;

public class Projeto_concorrentes{
    public static void main(String[] args) {
        
        MinhaThread thread = new MinhaThread("Thread #1",600,1);
        MinhaThread thread2 = new MinhaThread("Thread #2",1000,2);
        MinhaThread thread3 = new MinhaThread("Thread #3",1000,3);
        MinhaThread thread4 = new MinhaThread("Thread #4",600,4);
        MinhaThread thread5 = new MinhaThread("Thread #5",1000,5);
        MinhaThread thread6 = new MinhaThread("Thread #6",1000,6);        
        
        
        
    }
}
