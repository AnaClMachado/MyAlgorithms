package projeto_concorrentes;

import java.util.Random;

public class Numeros{
    
    public void gerador(int semente, int[] vet) {
 
        Random gerador = new Random(semente);
        //imprime sequência de 10 números inteiros aleatórios entre 0 e 25
        for (int i = 0; i < 10; i++) {
            vet[i]=gerador.nextInt();
        }
    }
}