package projeto_concorrentes;

public class MinhaThread extends Thread{
    
    public String nome;
    public int tempo;
    public int semente;
    public int[] vet=new int[10];
    Numeros gera = new Numeros();
    ordena shell = new ordena();
    
    
    public MinhaThread(String nome, int tempo, int semente) {
        this.nome = nome;
        this.tempo = tempo;
        this.semente = semente;
        start();
    }
    
    @Override
    public void run(){
        gera.gerador(semente, vet);
        shell.Shell_sort(vet,10);  
        for(int i=0;i<10;i++){
            System.out.println(nome+" "+vet[i]);
        }
    }
    
}
