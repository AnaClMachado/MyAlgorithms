package projeto_parte2;

import java.util.Random;

public class Usuario extends Thread{
    
    private String nome;
    private int prioridade;
    private int num_documentos;

    public Usuario(String nome, int prioridade) {
        this.nome = nome;
        this.prioridade = prioridade;
    }
    public void setNum_documentos(int num_documentos) {
        this.num_documentos = num_documentos;
    }

    public int getNum_documentos() {
        return num_documentos;
    }
  

    public int getPrioridade(){
        return prioridade;
    }

    public String getNome(){
        return nome;
    }
    
    public int gerador(){
             
        Random gerador = new Random();
        int semente;
        
        semente=gerador.nextInt(6);
        switch(semente){
            case 1:
                semente=11;
                break;
            case 2:
                semente=22;
                break;
            case 3:
                semente=33;
                break;
            case 4:
                semente=44;
                break;
            case 5:
                semente=55;
                break;
            case 6:
                semente=66;
                break;
        }
        
        for(int i=0;i<10;i++){
            System.out.println(" "+gerador());
        }
        
        return semente;        
        
    }
    
    @Override
    public void run(){
        Impressora impre = new Impressora();
        impre.imprimir(nome, num_documentos);       
     
    }
    
        
    
    
}
