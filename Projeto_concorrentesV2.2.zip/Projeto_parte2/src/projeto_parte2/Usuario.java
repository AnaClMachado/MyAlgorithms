package projeto_parte2;

import java.util.Random;

public class Usuario extends Thread{
    
    private String nome;
    private int prioridade;
    private int num_documentos=5;
    Impressora impre = new Impressora();
    
    public Usuario(String nome, int prioridade) {
        this.nome = nome;
        this.prioridade = prioridade;
    }
    public void setNum_documentos(int num_documentos) {
        this.num_documentos = num_documentos;
    }

    public int getNum_documentos() {
        return num_documentos;
    }
  

    public int getPrioridade(){
        return prioridade;
    }

    public String getNome(){
        return nome;
    }
    
    @Override
    public void run(){
        impre.imprimir(nome, num_documentos);           
    }
    
        
    
    
}
