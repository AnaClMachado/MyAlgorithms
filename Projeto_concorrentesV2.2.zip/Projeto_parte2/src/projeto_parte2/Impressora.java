package projeto_parte2;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author lesli
 */
public class Impressora {
    
    ArrayList<Usuario> lista = new ArrayList();
    
    public synchronized void adicionar_fila(String nome, int documento, int prioridade){
        
        Usuario novo = new Usuario(nome,prioridade);
        if(lista.size()<=2){
            if(lista.isEmpty()){
                lista.add(novo);
            }else if(prioridade>lista.get(0).getPrioridade()){
                lista.
            }
        }
    }
    
    
    public synchronized void imprimir(String nome, int documento){
        
        System.out.println("IMPRIMINDO");
        System.out.println("Usuario"+nome+""+" Documento"+documento);
        lista.remove(0);
    }
}
